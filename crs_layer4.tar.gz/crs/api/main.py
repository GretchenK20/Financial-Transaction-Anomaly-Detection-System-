"""
FastAPI scoring endpoint — serves champion model with SHAP explainability.
Routes: POST /score, GET /health, GET /champion, POST /batch_score
"""
import json
import numpy as np
import pandas as pd
import torch
import joblib
import shap
from pathlib import Path
from typing import Optional
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import DUCKDB_PATH
from models.autoencoder.train_autoencoder import (
    ClinicalAutoencoder, NUMERIC_FEATURES,
    MODEL_PATH as AE_MODEL_PATH, SCALER_PATH as AE_SCALER_PATH,
    MODEL_DIR as AE_DIR, preprocess, load_features,
)
from models.xgboost.train_xgboost import XGB_MODEL_PATH
from models.champion_challenger import load_registry

BASE_DIR = Path(__file__).parent.parent

app = FastAPI(
    title="Clinical Risk Scoring API",
    description="FHIR-ingested patient risk scoring with PyTorch autoencoder and XGBoost champion/challenger",
    version="1.0.0",
)

_ae_model = None
_ae_scaler = None
_xgb_bundle = None
_registry = None


def _load_models():
    global _ae_model, _ae_scaler, _xgb_bundle, _registry

    _registry = load_registry()

    # Load autoencoder
    if AE_MODEL_PATH.exists() and AE_SCALER_PATH.exists():
        import duckdb
        with duckdb.connect(str(DUCKDB_PATH), read_only=True) as conn:
            df = conn.execute(
                f"SELECT {', '.join(NUMERIC_FEATURES)} FROM main_gold.fct_patient_risk_features LIMIT 1"
            ).fetchdf()
        _, scaler, feature_cols = preprocess(df.assign(**{c: 0 for c in NUMERIC_FEATURES if c not in df}))
        _ae_scaler = joblib.load(AE_SCALER_PATH)
        input_dim = len(feature_cols)
        _ae_model = ClinicalAutoencoder(input_dim=input_dim)
        _ae_model.load_state_dict(torch.load(AE_MODEL_PATH, map_location="cpu"))
        _ae_model.eval()

    # Load XGBoost
    if XGB_MODEL_PATH.exists():
        _xgb_bundle = joblib.load(XGB_MODEL_PATH)


@app.on_event("startup")
def startup():
    _load_models()


class PatientFeatures(BaseModel):
    patient_id: str
    age_years: Optional[float] = None
    gender_male: Optional[float] = None
    is_deceased: Optional[float] = 0
    has_diabetes: Optional[float] = 0
    has_hypertension: Optional[float] = 0
    has_cad: Optional[float] = 0
    has_heart_failure: Optional[float] = 0
    has_asthma_or_copd: Optional[float] = 0
    has_ckd: Optional[float] = 0
    has_depression: Optional[float] = 0
    has_anxiety: Optional[float] = 0
    has_cancer: Optional[float] = 0
    total_active_conditions: Optional[float] = 0
    bmi: Optional[float] = None
    systolic_bp: Optional[float] = None
    diastolic_bp: Optional[float] = None
    cholesterol_total: Optional[float] = None
    is_obese: Optional[float] = 0
    elevated_systolic: Optional[float] = 0
    high_cholesterol: Optional[float] = 0
    total_encounters: Optional[float] = 0
    emergency_count: Optional[float] = 0
    inpatient_count: Optional[float] = 0
    encounters_last_12m: Optional[float] = 0
    care_span_days: Optional[float] = 0
    high_ed_utilizer: Optional[float] = 0
    composite_risk_score: Optional[float] = 0


class RiskScore(BaseModel):
    patient_id: str
    champion_model: str
    risk_score: float
    is_high_risk: bool
    risk_percentile: float
    ae_reconstruction_error: Optional[float]
    xgb_probability: Optional[float]
    top_risk_factors: list[dict]
    explanation: str


class BatchRequest(BaseModel):
    patients: list[PatientFeatures]


def _features_to_array(patient: PatientFeatures) -> np.ndarray:
    feature_map = {
        "age_years": patient.age_years,
        "gender_male": patient.gender_male,
        "is_deceased": patient.is_deceased,
        "has_diabetes": patient.has_diabetes,
        "has_hypertension": patient.has_hypertension,
        "has_cad": patient.has_cad,
        "has_heart_failure": patient.has_heart_failure,
        "has_asthma_or_copd": patient.has_asthma_or_copd,
        "has_ckd": patient.has_ckd,
        "has_depression": patient.has_depression,
        "has_anxiety": patient.has_anxiety,
        "has_cancer": patient.has_cancer,
        "total_active_conditions": patient.total_active_conditions,
        "bmi": patient.bmi,
        "systolic_bp": patient.systolic_bp,
        "diastolic_bp": patient.diastolic_bp,
        "cholesterol_total": patient.cholesterol_total,
        "is_obese": patient.is_obese,
        "elevated_systolic": patient.elevated_systolic,
        "high_cholesterol": patient.high_cholesterol,
        "total_encounters": patient.total_encounters,
        "emergency_count": patient.emergency_count,
        "inpatient_count": patient.inpatient_count,
        "encounters_last_12m": patient.encounters_last_12m,
        "care_span_days": patient.care_span_days,
        "high_ed_utilizer": patient.high_ed_utilizer,
        "composite_risk_score": patient.composite_risk_score,
    }
    arr = np.array([feature_map.get(f, 0.0) or 0.0 for f in NUMERIC_FEATURES])
    return arr.reshape(1, -1)


def _score_patient(patient: PatientFeatures) -> dict:
    registry = load_registry()
    champion = registry.get("champion", "xgboost")

    raw = _features_to_array(patient)

    ae_error = None
    xgb_prob = None
    shap_values = None
    feature_names = NUMERIC_FEATURES

    # Autoencoder score
    if _ae_model and _ae_scaler:
        X_scaled = _ae_scaler.transform(raw)
        X_t = torch.FloatTensor(X_scaled)
        ae_error = float(_ae_model.reconstruction_error(X_t).item())

    # XGBoost score + SHAP
    if _xgb_bundle:
        model = _xgb_bundle["model"]
        scaler = _xgb_bundle["scaler"]
        X_scaled = scaler.transform(raw)
        xgb_prob = float(model.predict_proba(X_scaled)[0, 1])

        explainer = shap.TreeExplainer(model)
        sv = explainer.shap_values(X_scaled)
        shap_values = sv[0] if sv.ndim > 1 else sv

    # Champion score for primary risk assessment
    if champion == "xgboost" and xgb_prob is not None:
        risk_score = xgb_prob
        is_high_risk = xgb_prob >= 0.5
    elif ae_error is not None:
        risk_score = min(ae_error / 0.5, 1.0)
        is_high_risk = ae_error >= 0.2110
    else:
        raise HTTPException(status_code=503, detail="No models loaded")

    # Load reference scores for percentile
    scores_path = AE_DIR / "anomaly_scores.parquet"
    risk_percentile = 50.0
    if scores_path.exists():
        ref = pd.read_parquet(scores_path)
        if champion == "xgboost":
            pct = float(np.mean(ref["anomaly_score"] <= risk_score) * 100)
        else:
            pct = float(np.mean(ref["anomaly_score"] <= (ae_error or 0)) * 100)
        risk_percentile = round(pct, 1)

    # Top risk factors from SHAP
    top_factors = []
    if shap_values is not None:
        pairs = sorted(
            zip(feature_names, shap_values),
            key=lambda x: abs(x[1]),
            reverse=True,
        )[:5]
        top_factors = [
            {"feature": f, "shap_value": round(float(v), 4), "direction": "increases" if v > 0 else "decreases"}
            for f, v in pairs
        ]

    # Plain language explanation
    risk_level = "high" if is_high_risk else "low"
    top_feature = top_factors[0]["feature"].replace("_", " ") if top_factors else "overall health profile"
    explanation = (
        f"Patient {patient.patient_id} has {risk_level} clinical risk "
        f"(score: {risk_score:.3f}, {risk_percentile}th percentile). "
        f"Primary driver: {top_feature}."
    )

    return {
        "patient_id": patient.patient_id,
        "champion_model": champion,
        "risk_score": round(risk_score, 4),
        "is_high_risk": is_high_risk,
        "risk_percentile": risk_percentile,
        "ae_reconstruction_error": round(ae_error, 4) if ae_error else None,
        "xgb_probability": round(xgb_prob, 4) if xgb_prob else None,
        "top_risk_factors": top_factors,
        "explanation": explanation,
    }


@app.get("/health")
def health():
    registry = load_registry()
    return {
        "status": "healthy",
        "champion": registry.get("champion"),
        "ae_loaded": _ae_model is not None,
        "xgb_loaded": _xgb_bundle is not None,
    }


@app.get("/champion")
def get_champion():
    registry = load_registry()
    return registry


@app.post("/score", response_model=RiskScore)
def score(patient: PatientFeatures):
    if _ae_model is None and _xgb_bundle is None:
        raise HTTPException(status_code=503, detail="Models not loaded")
    return _score_patient(patient)


@app.post("/batch_score")
def batch_score(request: BatchRequest):
    if _ae_model is None and _xgb_bundle is None:
        raise HTTPException(status_code=503, detail="Models not loaded")
    results = []
    errors = []
    for patient in request.patients:
        try:
            results.append(_score_patient(patient))
        except Exception as e:
            errors.append({"patient_id": patient.patient_id, "error": str(e)})
    return {"results": results, "errors": errors, "n_scored": len(results)}


@app.get("/patient/{patient_id}")
def score_from_db(patient_id: str):
    """Score a patient by ID using features from the gold layer."""
    try:
        import duckdb
        with duckdb.connect(str(DUCKDB_PATH), read_only=True) as conn:
            row = conn.execute(
                f"SELECT * FROM main_gold.fct_patient_risk_features "
                f"WHERE patient_id = ?",
                [patient_id],
            ).fetchdf()
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

    if row.empty:
        raise HTTPException(status_code=404, detail=f"Patient {patient_id} not found")

    r = row.iloc[0]
    patient = PatientFeatures(
        patient_id=patient_id,
        age_years=r.get("age_years"),
        gender_male=r.get("gender_male"),
        is_deceased=r.get("is_deceased", 0),
        has_diabetes=r.get("has_diabetes", 0),
        has_hypertension=r.get("has_hypertension", 0),
        has_cad=r.get("has_cad", 0),
        has_heart_failure=r.get("has_heart_failure", 0),
        has_asthma_or_copd=r.get("has_asthma_or_copd", 0),
        has_ckd=r.get("has_ckd", 0),
        has_depression=r.get("has_depression", 0),
        has_anxiety=r.get("has_anxiety", 0),
        has_cancer=r.get("has_cancer", 0),
        total_active_conditions=r.get("total_active_conditions", 0),
        bmi=r.get("bmi"),
        systolic_bp=r.get("systolic_bp"),
        diastolic_bp=r.get("diastolic_bp"),
        cholesterol_total=r.get("cholesterol_total"),
        is_obese=r.get("is_obese", 0),
        elevated_systolic=r.get("elevated_systolic", 0),
        high_cholesterol=r.get("high_cholesterol", 0),
        total_encounters=r.get("total_encounters", 0),
        emergency_count=r.get("emergency_count", 0),
        inpatient_count=r.get("inpatient_count", 0),
        encounters_last_12m=r.get("encounters_last_12m", 0),
        care_span_days=r.get("care_span_days", 0),
        high_ed_utilizer=r.get("high_ed_utilizer", 0),
        composite_risk_score=r.get("composite_risk_score", 0),
    )
    return _score_patient(patient)
